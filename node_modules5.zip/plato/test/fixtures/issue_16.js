/* global $:false */

// Note the space before the global keyword

(function () {
  'use strict';
  $.each([]);
})();
