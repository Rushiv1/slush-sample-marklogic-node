
0.2.7 / 2012-08-30
==================

  * Fixed handling of numeric inputs with parseFloat
  * Fixed overwriting of non-string inputs
  * Added support for boolean types

0.2.6 / 2012-08-12
==================

  * Added allowance of empty default values

