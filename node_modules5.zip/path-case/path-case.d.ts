declare function pathCase (value: string, locale?: string): string;

export = pathCase;
