# 2.0.2

* Now compiled with babel 6.

# 2.0.1

* Replaced javascript-natural-sort with alphanum-sort (thanks to @TrySound).

# 2.0.0

* Upgraded to PostCSS 5.

# 1.0.1

* Removed an unnecessary dependency on css-list.

# 1.0.0

* Initial release.
