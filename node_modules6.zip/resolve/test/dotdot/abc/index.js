var x = require('..');
console.log(x);
