
0.1.3 / 2012-10-17
==================

  * Fixed case problem with types

0.1.2 / 2012-06-27
==================

  * Added host-name String format
  * Added support for additionalProperties
  * Added few default validation messages for formats

0.1.1 / 2012-04-16
==================

  * Added default and custom error message support
  * Added suport for conform function
  * Updated date-time format

0.1.0 / 2011-11-09
=================

  * Initial release

