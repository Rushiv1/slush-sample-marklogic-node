declare function sentenceCase (value: string, locale?: string, replacement?: string): string;

export = sentenceCase;
