describe("less.js global vars", function() {
    testLessEqualsInDocument();
});
