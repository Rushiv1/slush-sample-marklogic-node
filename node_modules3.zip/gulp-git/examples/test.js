'use strict';

var that = 'test';
