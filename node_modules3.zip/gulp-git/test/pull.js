'use strict';

var fs = require('fs');
var path = require('path');
var rimraf = require('rimraf');
var should = require('should');
var gutil = require('gulp-util');

module.exports = function(git, testFiles, testCommit){

  /*
    it('should pull from the remote repo', function(done) {
      git.pull('origin', 'master', {cwd: "./test/"}, function(){
        should.exist('./test/.git/refs/heads/master');
        done();
      });
    });

  */

};
