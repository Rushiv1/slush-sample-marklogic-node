# 2.1.2

* Fixes an issue where gulp-cssnano was not passing on sourcemap errors and was
  crashing instead.

# 2.1.1

* Added more keywords for easier discovery on npm.

# 2.1.0

* Print a CssSyntaxError when the input CSS could not be parsed properly with
  PostCSS (thanks to @stelund).

# 2.0.1

* Bump object-assign and vinyl-sourcemaps-apply to latest versions.

# 2.0.0

* Upgrade to cssnano `3.0.0`.

# 1.1.0

* Upgrade to cssnano `2.0.0`.
* Bump other runtime dependencies.

# 1.0.0

* Initial release.
