(function () {
  'use strict';

  angular.module('app.snippet', [
    // html dependencies
    'ui.bootstrap'
  ]);
}());
