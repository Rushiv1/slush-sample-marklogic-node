(function () {
  'use strict';

  angular.module('app.error', [
    // inject dependencies
    'app.messageBoard',
    'ngToast'
  ]);
}());
