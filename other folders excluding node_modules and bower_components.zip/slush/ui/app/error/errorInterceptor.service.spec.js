/* jshint -W117, -W030 */
(function () {
  'use strict';

  describe('Service: errorInterceptor', function () {

    beforeEach(function() {
      bard.appModule('app.error');
      bard.inject('$http');
    });

    it('should be created successfully', function () {
      // no expects, just for code coverage
    });

  });
}());
