(function () {
  'use strict';

  angular.module('app.route', [
    // inject dependencies
    'app.user',
    'ml.common',
    'ui.router'
  ]);
}());
