(function () {
  'use strict';

  angular.module('app.messageBoard', [
    // dependencies
    'ui.router' // for $stateChangeSuccess event
  ]);
}());
