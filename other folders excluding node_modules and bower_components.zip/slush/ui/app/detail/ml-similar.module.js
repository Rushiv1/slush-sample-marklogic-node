(function() {
  'use strict';

  angular.module('app.similar', [
    // inject dependencies
    'ml.common',

    // html dependencies
    'ui.router'
  ]);

}());
